package br.com.sonora.models;

public class Title {
    private String name;
    private int anoDeLancamento;
    private double ranking;
    private int duracaoEmMinuto;
    private int artist;

    public Title() {
        this.name = name;
        this.anoDeLancamento = anoDeLancamento;
        this.ranking = ranking ;
        this.duracaoEmMinuto = duracaoEmMinuto;
        this.artist = artist;
    }

    public Title(String nome, int anoDeLancamento, double ranking, int artist, int duracaoEmMinuto) {
    }

    public int getArtist() {
        return artist;
    }

    public void setArtist(int artist) {
        this.artist = artist;
    }

    public int getAnoDeLancamento() {
        return anoDeLancamento;
    }

    public void setAnoDeLancamento(int anoDeLancamento) {
        this.anoDeLancamento = anoDeLancamento;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getRanking() {
        return ranking;
    }

    public void setRanking(double ranking) {
        this.ranking = ranking;
    }

    public int getDuracaoEmMinuto() {
        return duracaoEmMinuto;
    }

    public void setDuracaoEmMinuto(int duracaoEmMinuto) {
        this.duracaoEmMinuto = duracaoEmMinuto;
    }

    public void exibeTitulo() {
        System.out.println("Nome: " + name);
        System.out.println("Ano de Lançamento: " + anoDeLancamento);
        System.out.println("Ranking: " + ranking);
        System.out.println("Duração (minutos): " + duracaoEmMinuto);
        System.out.println("Artista ID: " + artist);
    }

}
