package br.com.sonora.models;
import br.com.sonora.models.Title;

public class Playlist extends Title {
    private String namePlaylist;

    public Playlist(String nome, int anoDeLancamento, double ranking, int duracaoEmMinuto, int artist) {
        super(nome,anoDeLancamento, ranking, artist, duracaoEmMinuto);
    }

    public String getNamePlaylist() {
        return namePlaylist;
    }

    public void setNamePlaylist(String namePlaylist) {
        this.namePlaylist = namePlaylist;
    }
}
