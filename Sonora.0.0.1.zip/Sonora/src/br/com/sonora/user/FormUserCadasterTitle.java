package br.com.sonora.user;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import br.com.sonora.models.Title;
import br.com.sonora.models.Podcast;
public class FormUserCadasterTitle {

    private static List<Title> titles = new ArrayList<>();
    private static List<Podcast> podcasts = new ArrayList<>();
    private static int artistIdCounter = 1;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

         //menu
        while (running) {
            System.out.println("Escolha uma opção:");
            System.out.println("1. Cadastrar Título");
            System.out.println("2. Cadastrar Podcast");
            System.out.println("3. Excluir Título");
            System.out.println("4. Excluir Podcast");
            System.out.println("5. Listar Títulos");
            System.out.println("6. Listar Podcasts");
            System.out.println("0. Sair");

            int option = scanner.nextInt();
            scanner.nextLine(); // Consumir nova linha

            switch (option) {
                case 1:
                    cadastrarTitle(scanner);
                    break;
                case 2:
                    cadastrarPodcast(scanner);
                    break;
                case 3:
                    excluirTitle(scanner);
                    break;
                case 4:
                    excluirPodcast(scanner);
                    break;
                case 5:
                    listarTitles();
                    break;
                case 6:
                    listarPodcasts();
                    break;
                case 0:
                    running = false;
                    break;
                default:
                    System.out.println("Opção inválida.");
                    break;
            }
        }

        scanner.close();
    }
// cadastro
    private static void cadastrarTitle(Scanner scanner) {
        Title title = new Title();

        System.out.print("Nome do Título: ");
        title.setName(scanner.nextLine());

        System.out.print("Ano de Lançamento: ");
        title.setAnoDeLancamento(scanner.nextInt());

        System.out.print("Duração em Minutos: ");
        title.setDuracaoEmMinuto(scanner.nextInt());

        title.setArtist(artistIdCounter++); // id unica por artista
        scanner.nextLine();
        titles.add(title);
        System.out.println("Título cadastrado com sucesso.");
    }
// podcasto
    private static void cadastrarPodcast(Scanner scanner) {
        Podcast podcast = new Podcast();
//vc pode adicionar um podcast sozin ou um ep completo
        //falta atualizar 2 coisas: contabilizar eps tbm
        //opção de fechar temps
        System.out.println("Nome do Podcast: ");
        podcast.setNomePod(scanner.nextLine());
        System.out.print("Deseja adicionar um novo episodio? ");
        boolean addingEpisodes = true;
        while (addingEpisodes) {
            System.out.print("Deseja adicionar um novo episódio? (s/n): ");
            String resposta = scanner.nextLine();
            if (resposta.equalsIgnoreCase("s")) {
                System.out.print("Nome do Episódio: ");
                String episodio = scanner.nextLine();
                podcast.addEpisodio(episodio);
                System.out.println("Descrição do Episodio:");
                String descricao = scanner.nextLine();
                podcast.setDescricaoEp();
            } else if (resposta.equalsIgnoreCase("n")) {
                addingEpisodes = false;
            } else {
                System.out.println("Resposta inválida. Por favor, digite 's' ou 'n'.");
            }
        }


        podcasts.add(podcast);
        System.out.println("Podcast cadastrado com sucesso.");
    }

    private static void excluirTitle(Scanner scanner) {
        listarTitles();
        System.out.print("Digite o índice do título a ser excluído: ");
        int index = scanner.nextInt();
        scanner.nextLine(); // Consumir nova linha

        if (index >= 0 && index < titles.size()) {
            titles.remove(index);
            System.out.println("Título excluído com sucesso.");
        } else {
            System.out.println("Índice inválido.");
        }
    }

    private static void excluirPodcast(Scanner scanner) {
        listarPodcasts();
        System.out.print("Digite o índice do podcast a ser excluído: ");
        int index = scanner.nextInt();
        scanner.nextLine(); // Consumir nova linha

        if (index >= 0 && index < podcasts.size()) {
            podcasts.remove(index);
            System.out.println("Podcast excluído com sucesso.");
        } else {
            System.out.println("Índice inválido.");
        }
    }
    //aqui entrei em desespero
    private static void listarTitles() {
        System.out.println("Títulos cadastrados:");
        for (int i = 0; i < titles.size(); i++) {
            Title title = titles.get(i);
            System.out.printf("%d. Nome: %s, Ano: %d, Duração: %d, Artista: %d%n",
                    i, title.getName(), title.getAnoDeLancamento(), title.getDuracaoEmMinuto(), title.getArtist());
        }
    }

    private static void listarPodcasts() {
        System.out.println("Podcasts cadastrados:");
        for (int i = 0; i < podcasts.size(); i++) {
            Podcast podcast = podcasts.get(i);
            System.out.printf("%d. Temporadas: %d, Episódios por Temporada: %d, Minutos por Episódio: %d%n",
                    i, podcast.getTemporadas(), podcast.getEpisodiosPorTemporada(), podcast.getMinutosPorEpisodio());
        }
    }
}
