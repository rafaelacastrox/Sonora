package br.com.sonora.user;

public class FormUserAutoCadaster {
}
