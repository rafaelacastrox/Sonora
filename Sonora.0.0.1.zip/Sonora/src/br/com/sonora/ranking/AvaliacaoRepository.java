package br.com.sonora.ranking;
import java.util.HashMap;
import java.util.Map;

public class AvaliacaoRepository {

    // Armazenamento da Mémoria

    private Map<Long, Ava> bancoDeDados = new HashMap<>();
    private long proximoId = 1;

    //Método para adicionar uma avaliação

    public Ava adicionarAvaliacao(Ava avaliacao) {
        if (avaliacao.getId() == null) {
            avaliacao.setId(proximoId++);
        }
        bancoDeDados.put(avaliacao.getId(), avaliacao);
        return avaliacao;
    }

    //Buscar av por Id
      public Ava buscarAvaliacaoPorId(Long id){
          return bancoDeDados.get(id);
      }

      //Att avaliação
      public Ava atualizarAvaliacao(Ava avaliacao) {
          if (avaliacao.getId() != null && bancoDeDados.containsKey(avaliacao.getId())) {
              bancoDeDados.put(avaliacao.getId(), avaliacao);
              return avaliacao;
          }
          return null;
      }

      //Remover av
    public boolean removerAvaliacao(Long id) {
        return bancoDeDados.remove(id) != null;
    }

    // listar avaliacoes (aqui eu já tava pedindo socorro)

    public Map <Long, Ava> listarAvaliacoes(){
        return new HashMap<>(bancoDeDados);
    }
    }