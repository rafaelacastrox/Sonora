package br.com.sonora.main;

import br.com.sonora.ranking.Ava;
import br.com.sonora.models.Title;
import br.com.sonora.models.Podcast;
import br.com.sonora.models.Playlist;
import br.com.sonora.models.AudioBook;



public class Main {
    public static void main(String[] args) {
        System.out.println("Teste");
    }
}