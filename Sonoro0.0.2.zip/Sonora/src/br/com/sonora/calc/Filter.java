package br.com.sonora.calc;

public class Filter {
}
