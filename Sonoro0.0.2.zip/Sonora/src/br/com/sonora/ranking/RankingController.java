package br.com.sonora.ranking;

public class RankingController {

}
