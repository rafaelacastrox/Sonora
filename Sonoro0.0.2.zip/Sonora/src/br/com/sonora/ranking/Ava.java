package br.com.sonora.ranking;

public class Ava {
    private Long id;
    private Long tituloId;
    private int nota;
    private int avaliacao;

    public Ava(Long id, Long tituloId, int nota, int avaliacao) {
        this.id = id;
        this.tituloId = tituloId;
        this.nota = nota;
        this.avaliacao = avaliacao;
    }

    public int getAvaliacao() {
        return avaliacao;
    }

    public void setAvaliacao(int avaliacao) {
        this.avaliacao = avaliacao;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTituloId() {
        return tituloId;
    }

    public void setTituloId(Long tituloId) {
        this.tituloId = tituloId;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }
}
