package br.com.sonora.user;

import java.util.Scanner;

public class FormUserAutoCadaster {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //coletar dados
        System.out.println("Crie o seu nome de usuario");
        String username = scanner.nextLine();

        System.out.println("E-mail:");
        String email = scanner.nextLine();

        System.out.println("Confirmar o e-mail: ");
        String confirmarEmail = scanner.nextLine();

        //verifica email
        if (!email.equals(confirmarEmail)) {
            System.out.println("Os emails não coincidem. por favor digite novamente: ");
            scanner.close();
            return;
        }
        // Coletar senha
        System.out.print("Senha: ");
        String password = scanner.nextLine();

        // Confirmar senha
        System.out.print("Confirme a senha: ");
        String confirmPassword = scanner.nextLine();

        // Verificar se as senhas coincidem
        if (!password.equals(confirmPassword)) {
            System.out.println("As senhas não coincidem. Por favor, tente novamente.");
            scanner.close();
            return;
        }

        // Se tudo estiver correto
        System.out.println("Cadastro realizado com sucesso!");
        System.out.printf("Nome de Usuário: %s%nE-mail: %s%n", username, email);

        scanner.close();
    }
}
