package br.com.sonora.models;
import br.com.sonora.models.Title;

public class AudioBook extends Title {

    public AudioBook(String nome, int anoDeLancamento, double ranking, int duracaoEmMinuto, int artist) {
        super(nome,anoDeLancamento, ranking, artist, duracaoEmMinuto);
    }
    }

