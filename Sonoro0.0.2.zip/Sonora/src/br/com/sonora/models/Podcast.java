package br.com.sonora.models;

import br.com.sonora.models.Title;

public class Podcast {
    private String nomePod;
    private String nomeEp;
    private int temporadas;
    private int episodiosPorTemporada;
    private int minutosPorEpisodio;
    private boolean addEp;

    public boolean isAddEp() {
        return addEp;
    }

    public void setAddEp(boolean addEp) {
        this.addEp = addEp;
    }

    // Construtor padrão
    public Podcast() {
        // Inicializa com valores padrão, se necessário
    }

    // Getters e Setters
    public int getEpisodiosPorTemporada() {
        return episodiosPorTemporada;
    }

    public void setEpisodiosPorTemporada(int episodiosPorTemporada) {
        this.episodiosPorTemporada = episodiosPorTemporada;
    }

    public int getTemporadas() {
        return temporadas;
    }

    public void setTemporadas(int temporadas) {
        this.temporadas = temporadas;
    }

    public int getMinutosPorEpisodio() {
        return minutosPorEpisodio;
    }

    public void setMinutosPorEpisodio(int minutosPorEpisodio) {
        this.minutosPorEpisodio = minutosPorEpisodio;
    }

    public String getNomePod() {
        return nomePod;
    }

    public void setNomePod(String nomePod) {
        this.nomePod = nomePod;
    }

    public String getNomeEp() {
        return nomeEp;
    }

    public void setNomeEp(String nomeEp) {
        this.nomeEp = nomeEp;
    }
// ta uma zona
    public void addEpisodio(String episodio) {
    }

    public void setDescricaoEp() {
    }
}
