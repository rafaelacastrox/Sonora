package br.com.sonora.main;

import br.com.sonora.ranking.Ava;
import br.com.sonora.models.Title;
import br.com.sonora.models.Podcast;
import br.com.sonora.models.Playlist;
import br.com.sonora.models.AudioBook;


///////////////// Segurei na mão de Deus e não desisti, seja o que ele quiser
////////// Melhor não mexer, tá funfando
/////// Eu que fiz: @rafaelacastrox se eu ver copia, o negocio vai ficar louco, dois beijos
//// é meme

public class Main {
    public static void main(String[] args) {
        System.out.println();
    }
}